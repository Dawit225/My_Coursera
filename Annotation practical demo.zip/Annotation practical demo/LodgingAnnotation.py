import json
import psycopg2
import tkinter as tk
from tkinter import font
import xmltodict

Host = 'gip.itc.utwente.nl'
Port = '5434'
DB = 'c122'
User = 's2257335'
Pass = '__s2257335___'


Conn = psycopg2.connect(host = Host, port = Port, dbname = DB, user = User, password = Pass)
Cur = Conn.cursor()


# with open("D:/MSc Research/draw.io/Lodgedetection.xml") as xml_file:
#     data_dict = xmltodict.parse(xml_file.read())
#     xml_file.close()

    # generate the object using json.dumps()
    # corresponding to json data

    # json_data = json.dumps(data_dict)

    # Write the json data to output
    # json file
    # with open("D:/MSc Research/draw.io/data.json", "w") as json_file:
    #     json_file.write(json_data)
    #     json_file.close()

# Set the path according to the location where you put the data
File = open('D:/MSc Research/draw.io/Lodgedetection.json', encoding='utf-8-sig')
Data = json.load(File)

W_elements = list()
final_splitted = list()
for i in range(24, 35):
    # name = (Data["mxfile"]["diagram"]["mxGraphModel"]["root"]["mxCell"][i]["_value"])
    W_elements.append(Data["mxfile"]["diagram"]["mxGraphModel"]["root"]["mxCell"][i]["_value"])

for i in range(len(W_elements)):
    final_splitted.append(W_elements[i][3:-4])
                                    
# print(W_elements)
# print(final_splitted)
check = final_splitted[2]
sql = "select definition from ltb where label = '%s'" %check
Cur.execute(sql)
result = Cur.fetchone()
resfin  = str(result[0])
# print(type(resfin))
# root.geometry("500x500")

root = tk.Tk()
root.title(check)
text = tk.Text(root, wrap="word", width=60, height=10)
text.pack(fill="both", expand=True)

text_font = font.nametofont(text.cget("font"))
bullet_width = text_font.measure("- ")
em = text_font.measure("m")
text.tag_configure("bulleted", lmargin1=em, lmargin2=em+bullet_width)

text.insert("end", "- " + resfin, "bulleted")

root.mainloop()
Conn.commit()



# print(Data["mxfile"]["diagram"]["mxGraphModel"]["root"]["mxCell"][24])

# fun_name = Data['workflows'][0]['operations'][0]['metadata']['longname']
# print(Data['workflows'][0]['operations'][0]['metadata']['longname'])

# json_file_path = "D:/MSc Research/draw.io/Lodgedetection.json"
#
# with open(json_file_path, 'r') as j:
#      contents = json.loads(j.read())

# with open("D:/MSc Research/draw.io/Lodgedetection.json", encoding='utf-8-sig', errors='ignore') as json_data:
#     data = json.load(json_data, strict=False)
#
# print(data)
# To parse and hold the name of the operation from the imported workflow

# fun_name = Data['workflows'][0]['operations'][0]['metadata']['longname']
# print(Data['workflows'][0]['operations'][0]['metadata']['longname'])

# To split the operation
#
# fun_split = fun_name.split(":")
# final_fun = fun_split[1]

# To query a database table using the variable which holds the operation name

# sql = "select definition from ltb where label = '%s'" %final_fun
# Cur.execute(sql)
# result = Cur.fetchone()
# print(result)
#
# Conn.commit()

